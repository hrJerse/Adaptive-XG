README – Adaptive-XG Preprint Supplementary Files

This Zenodo record contains the preprint PDF of the Adaptive-XG project together with supplementary CSV files used in the analysis. 
The CSV files correspond to tables and results referenced in the manuscript chapters. 

File descriptions:

Table_3.1_1_SPARC_Master.csv  → SPARC master fit results for model selection (ΔAIC, ΔBIC, χ²_red)
Table_3.1_2_TopBottom10.csv   → Top/Bottom 10 galaxies ranked by ΔAIC performance
Table_3.3_1_RAR_RMS.csv       → Radial Acceleration Relation (RAR) RMS residuals
Table_3.3_2_BTFR_Fit.csv      → Baryonic Tully-Fisher Relation (BTFR) best-fit slope and scatter
Table_4.2_1_maxBCG_ALL.csv    → SDSS maxBCG stacked lensing profile with covariance
Table_4.3_1_SLACS.csv         → SLACS strong-lensing Einstein radii per lens
Table_4.4_1_WeakStack.csv     → Weak-lensing stacked shear profile (KiDS/DES representative sample)

Notes:
- All tables are provided in CSV format with headers.
- Units are consistent with the descriptions in the manuscript (R[Mpc], ΔΣ[M⊙ pc⁻²], θ_E[arcsec]).
- These files are intended for reproducibility of the figures and tables in Chapters 3 and 4 of the preprint.

Contact: Hamid Reza Jerse (Independent Researcher, Adaptive-XG Project)
