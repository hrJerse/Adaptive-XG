# Cosmology Supplement — Adaptive-(Chi-Gravity)XG (Paper III)

This folder contains the *reproducible* assets used in Sections 2–6 of Paper III.

## Contents
- **Data (CSV)**
  - `AXG_BAO_compilation_section2.csv` — BAO distances (6dFGS, SDSS MGS, BOSS DR12, eBOSS).
  - `Section5_BAO_DV_over_rd.csv` — Subset of BAO points used in Fig. 5.1.
  - `f_sigma8_compilation_AXG_PaperIII.csv` — Growth-rate measurements (fσ8) from 6dFGS, SDSS-MGS, BOSS DR12, eBOSS.
  - `AXG_S8_compilation_section4.csv` — Weak-lensing S8 constraints (DES Y3, KiDS-1000, Planck).
  - `Section5_theta_star_Planck2018.csv` — CMB acoustic scale θ* (Planck 2018).
  - `Section5_Planck2018_A_L.csv` — CMB lensing amplitude A_L (Planck 2018) + AXG baseline expectation.

- **Figures (PNG)**
  - `fig_fsigma8_compilation.png` — Observed fσ8 points (Sec. 3).
  - `AXG_BAO_DVoverrd.png` — Low-z BAO D_V/r_d (Sec. 2).
  - `AXG_BAO_comparison_TestA_TestB.png` — BAO ladder: data vs AXG Test A/B (Sec. 5).
  - `AXG_S8_comparison.png` — S8 bar chart (Sec. 4).

- **Notebook**
  - `AXG_growth_solver.ipynb` — Integrates the linear growth equation and compares to fσ8 data.
  
## Quick Start
1. Open `AXG_growth_solver.ipynb` in Jupyter.
2. Run the notebook (no internet required). The notebook will:
   - Load `f_sigma8_compilation_AXG_PaperIII.csv`.
   - Integrate the growth ODE for two scenarios: *Test A* and *Test B*.
   - Plot fσ8(z) theory vs. data and report a simple χ² (illustrative).
3. Adjust parameters in the first cell:
   - `Omega_b`, `Omega_m_eff`, `Omega_XG_DE`, `mu_linear`, `w_XG`.
   - Set `scenario = "A"` or `scenario = "B"` to toggle.

## Notes
- The background is modeled as:
  - **Test A:** H²/H₀² = Ω_b a⁻³ + Ω_XG,DE (w≈−1).
  - **Test B:** H²/H₀² = Ω_m,eff a⁻³ + Ω_XG,Λ.
- The growth equation (linear, sub-horizon) is:
  \[
  D'' + [2 + H'/H] D' - \frac{3}{2}\,\Omega_m(a)\,\mu(a,k)\,D = 0,
  \]
  with primes ≡ d/d ln a, and \(\Omega_m(a)=\Omega_{m,eff} a^{-3}/E(a)^2\).
- Default `sigma8_0` can be set to Planck 2018 value (0.811), but feel free to vary it.

## Reproducibility
The CSV files contain only published values (no fabricated numbers). For large SN tables (Pantheon, Pantheon+), please use the official releases described in the manuscript.